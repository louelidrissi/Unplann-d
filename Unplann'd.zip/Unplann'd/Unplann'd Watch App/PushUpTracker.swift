//
//  PushUpTacker.swift
//  Unplann'd
//
//  Created by Lou El Idrissi on 3/25/25.
//

import SwiftUI

struct PushUpTracker: View {
    var body: some View {
        VStack {
            Text("Push-Up Tracker")
                .font(.title)
                .fontWeight(.bold)
                .padding()
        }
    }
}

