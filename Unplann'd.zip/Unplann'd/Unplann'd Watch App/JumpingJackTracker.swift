//
//  JumpingJackTracker.swift
//  Unplann'd
//
//  Created by Lou El Idrissi on 3/25/25.
//

import SwiftUI

struct JumpingJackTracker: View {
    var body: some View {
        VStack {
            Text("Jumping Jack Tracker")
                .font(.title)
                .fontWeight(.bold)
                .padding()
         
            Spacer()
        }
        
    }
}
